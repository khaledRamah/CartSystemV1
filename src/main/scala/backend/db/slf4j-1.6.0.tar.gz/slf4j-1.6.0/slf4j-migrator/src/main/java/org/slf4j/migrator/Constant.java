package org.slf4j.migrator;

public class Constant {

  public final static int JCL_TO_SLF4J = 0;
  public final static int LOG4J_TO_SLF4J = 1;
  public final static int JUL_TO_SLF4J = 2;
  public final static int NOP_TO_SLF4J = 3;

  public final static int NB_FILES_MAX = 1;

}