
document.write('<table class="footer">')

document.write('<tr>')

document.write('  <td>')

//document.write('    <a href="http://validator.w3.org/check?uri=referer">')
//document.write('      <img align="left" src="http://www.w3.org/Icons/valid-xhtml10"') 
//document.write('           alt="Valid XHTML 1.0 Transitional" height="31" width="88" /></a>')
document.write('   </td>')

document.write('<td valign="top">Copyright &copy; 2004-2010  <a href="http://www.qos.ch/">QOS.ch</a></td>')

document.write('</tr>')
document.write('</table>')


